<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Libreria</title>
	<link rel="stylesheet" type="text/css" href="<?=base_url()?>assets/css/estilos.css">

</head>
<body>

<div id="container">
	<?=$header?>
	<section>
		<h1>Alta</h1>
		<div id="alerta"></div><br>
		<form method="post" action=""> 
			<label>Título: </label><input type="text" maxlenght="200" id="titulo" name="titulo" /><br><br>
			<label>Precio: </label><input type="number" maxlenght="5" id="precio" name="precio" /><br><br>
			<input type="submit" name="alta" id="alta" value="Alta Libro" />
		</form><br>
		<center><a href="<?=base_url()?>">Volver a inicio</a></center><br>
	</section>
	<?=$footer?>
</div>
</body>
</html>