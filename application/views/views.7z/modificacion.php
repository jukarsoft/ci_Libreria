<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Libreria</title>
	<link rel="stylesheet" type="text/css" href="<?=base_url()?>assets/css/estilos.css">
</head>
<body>

<div id="container" class='justify'>
	<?=$header?>
	<section>
		<h1>Modificación</h1>
		<div id="alerta"></div>
		<label>Título del libro: </label><br>
		<form method='post' action=''>
			<select id="libro" name='libro'>
				<option disabled selected value='-1'>Seleccione libro</option>
				
			</select>
		</form>
		<br><br>
		<form id="formulario" method="post" action="">
			<input type="hidden" id="idlibro" name="idlibro" value="" />
			<label>Título: </label><input class="fields" type="text" maxlenght="200" id="titulo" name="titulo" value="" /><br><br>
			<label>Precio: </label><input class="fields" type="number" maxlenght="5" id="precio" name="precio" value="" /><br><br>
			<center><input type="submit" name="modificacion" id="modificacion" value="Modificar" /></center>
		</form><br>
		<center><a href="<?=base_url()?>">Volver a inicio</a></center><br>
	</section>
	<?=$footer?>
</div>
</body>
</html>