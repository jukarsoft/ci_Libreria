<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Libreria</title>

	<link rel="stylesheet" type="text/css" href="<?=base_url()?>assets/css/estilos.css">
</head>
<body>

<div id="container">
	<?=$header?>
	<section>
		<h1>Consulta</h1>
		
		<center><a href="<?=base_url()?>">Volver a inicio</a></center><br>
	</section>
	<?=$footer?>
</div>
</body>
</html>