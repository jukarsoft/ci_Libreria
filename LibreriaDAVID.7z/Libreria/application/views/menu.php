<!doctype html>
<html>
	<head>
		<title>libreria</title>
		<meta charset="UTF-8">
		<link rel="stylesheet" href="<?=base_url()?>assets/css/estilos.css">
	</head>
	<body>
		<?=$cabecera?>
		<section>
			<h2>MENU DE OPCIONES</h2>
			<a href="<?=base_url()?>inicio/alta">Alta</a><br><br>
			<a href="<?=base_url()?>inicio/baja">Baja</a><br><br>
			<a href="<?=base_url()?>inicio/modificacion">Modificación</a><br><br>
			<a href="<?=base_url()?>inicio/consulta">Consulta</a><br>
		</section>
		<?=$piePagina?>
	</body>
</html>