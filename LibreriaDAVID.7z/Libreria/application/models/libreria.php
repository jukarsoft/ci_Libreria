<?php
	class Libreria extends CI_Model {
		public function consultaLibros() {

		}

		public function altaLibro($alta) {
			//insertar los datos
			$this->db->insert('libros', $alta);

			//recuperar el id del libro insertado
			$id = $this->db->insert_id();

			//respuesta del modelo
			return "alta efectuada con id $id";
		}

		public function bajaLibro() {

		}

		public function modificaLibro() {

		}
	}

?>