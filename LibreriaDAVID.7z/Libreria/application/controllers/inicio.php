<?php
	class Inicio extends CI_Controller {
		public function index() {
			//cargar las secciones comunes para enviarlas a la vista
			$datos['cabecera'] = $this->load->view('header', '', true);
			$datos['piePagina'] = $this->load->view('footer', '', true);

			$this->load->view('menu', $datos);
		}

		public function alta() {
			//cargar las secciones comunes para enviarlas a la vista
			$datos = $this->cargarSecciones();

			$datos['respuesta']='';

			$this->load->view('alta', $datos);
		}

		public function baja() {
			//cargar las secciones comunes para enviarlas a la vista
			$datos = $this->cargarSecciones();

			//consulta al modelo para recuperar el array de libros

			//enviar la vista
			$this->load->view('baja', $datos);
		}

		public function modificacion() {
			//cargar las secciones comunes para enviarlas a la vista
			$datos = $this->cargarSecciones();

			//consulta al modelo para recuperar el array de libros

			//enviar la vista
			$this->load->view('modificacion', $datos);
		}

		public function consulta() {
			//cargar las secciones comunes para enviarlas a la vista
			$datos = $this->cargarSecciones();

			//consulta al modelo para recuperar el array de libros

			//enviar la vista
			$this->load->view('consulta', $datos);
		}

		private function cargarSecciones() {
			return array('header'=>$this->load->view('header', '', true), 'footer'=>$this->load->view('footer', '', true));
		}
	}
?>