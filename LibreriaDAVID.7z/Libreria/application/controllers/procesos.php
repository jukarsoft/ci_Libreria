<?php
	class Procesos extends CI_Controller {
		public function altaLibro() {
			//recuperar los datos del formulario
			$titulo = $this->input->post('titulo');
			$precio = $this->input->post('precio');

			//llamar al modelo para el alta del libro
			$alta = array('titulo'=>$titulo, 'precio'=>$precio);

			$respuesta = $this->Libreria->altaLibro($alta);

			//cargar las secciones comunes para enviarlas a la vista
			$datos = $this->cargarSecciones();

			//cargar la vista con la respuesta
			$datos['respuesta'] = $respuesta;

			$this->load->view('alta', $datos);
		}

		private function cargarSecciones() {
			return array('header'=>$this->load->view('header', '', true), 'footer'=>$this->load->view('footer', '', true));
		}
	}
?>